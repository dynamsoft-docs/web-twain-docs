# Dynamic Web TWAIN HelloWorld 

* HelloWorld-Using-LocalResources.html: example in the guide using local resources
* HelloWorld-Using-CDN.html: the same example except that it is using CDN

You can download the resources on the download page: https://www.dynamsoft.com/web-twain/downloads/

You can typically find the Resources folder inside the following locations depending on your platform:

* Windows: C:\Program Files (x86)\Dynamsoft\Dynamic Web TWAIN SDK {Version Number}\
* Linux: Within the decompressed file Dynamic Web TWAIN SDK {Version Number}/
* macOS: Applications/Dynamsoft/Dynamic Web TWAIN SDK {Version Number}/